import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from '../admin-service.service';
import { Merchant } from '../Merchant';

@Component({
  selector: 'app-pending-requests',
  templateUrl: './pending-requests.component.html',
  styleUrls: ['./pending-requests.component.css']
})
export class PendingRequestsComponent implements OnInit {

  merchant:Merchant[];
  isValid: string;

  constructor(private httpClientService:AdminServiceService) { }

  ngOnInit() {
  
      this.httpClientService.pendingRequests().subscribe(
        data=>{
          this.merchant=data;
        }
      )
    
  }

  acceptMerchant(merId:string){
    this.httpClientService.acceptMerchant(merId).subscribe(
      data=>{
        this.merchant=data;
      }
    );
  }

  denyMerchant(merId:string){
    this.httpClientService.denyMerchant(merId).subscribe(
      data=>{
        this.merchant=data;
      }
    );
  }

  

}
