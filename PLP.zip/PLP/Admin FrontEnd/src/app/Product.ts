import { Merchant } from './merchant';
import { ProductRating } from './ProductRating';


export class Product {

    prodId:string;
    prodName:string;
    prodCategory:string;
    price:number;
    discount:number;
    validTime:string;
    promoCode:string;
    viewsCount:string;
    merchant: Merchant;
    productRating: ProductRating;
    qty:number;
    constructor(prodId:string,prodName:string,prodCategory:string,price:number,discount:number,validTime:string,promoCode:string,viewsCount:string,merchant: Merchant,productRating: ProductRating,qty:number){
            this.prodId=prodId;
            this.prodName=prodName;
            this.prodCategory=prodCategory;
            this.price=price;
            this.discount=discount;
            this.validTime=validTime;
            this.promoCode=promoCode;
            this.viewsCount=viewsCount;
            this.merchant=merchant;
            this.productRating=productRating;
            this.qty=qty;
        }
}
