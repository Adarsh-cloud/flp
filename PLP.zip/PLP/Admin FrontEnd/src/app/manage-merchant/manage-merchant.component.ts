import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-merchant',
  templateUrl: './manage-merchant.component.html',
  styleUrls: ['./manage-merchant.component.css']
})
export class ManageMerchantComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
