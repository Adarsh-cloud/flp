import { Component, OnInit } from '@angular/core';
import { AdminpageComponent } from '../adminpage/adminpage.component';
import { AdminServiceService } from '../admin-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-dedicated-merchant',
  templateUrl: './add-dedicated-merchant.component.html',
  styleUrls: ['./add-dedicated-merchant.component.css']
})
export class AddDedicatedMerchantComponent implements OnInit {
  constructor(private adminService: AdminServiceService, private routes: Router) { }

  ngOnInit() {
    this.adminService.setFromAdminDD(true);
    this.routes.navigateByUrl("/register");
  }
}
