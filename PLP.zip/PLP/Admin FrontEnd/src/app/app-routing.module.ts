import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowCustomersComponent } from './show-customers/show-customers.component';
import { ShowMerchantsComponent } from './show-merchants/show-merchants.component';
import { ShowInventoryComponent } from './show-inventory/show-inventory.component';

import { ShowEmailLogComponent } from './show-email-log/show-email-log.component';
import { PendingRequestsComponent } from './pending-requests/pending-requests.component';
import { TotalRevenueComponent } from './total-revenue/total-revenue.component';

import { ManageMerchantComponent } from './manage-merchant/manage-merchant.component';
import { AddDedicatedMerchantComponent } from './add-dedicated-merchant/add-dedicated-merchant.component';
import { AddThirdPartyMerchantComponent } from './add-third-party-merchant/add-third-party-merchant.component';
import { RemoveMerchantComponent } from './remove-merchant/remove-merchant.component';
import { InviteThirdPartyMerchantComponent } from './invite-third-party-merchant/invite-third-party-merchant.component';
import { SignUpMerchantComponent } from './sign-up-merchant/sign-up-merchant.component';
import { InboxEmailComponent } from './inbox-email/inbox-email.component';
import { SentMailComponent } from './sent-mail/sent-mail.component';
import { ReportComponent } from './report/report.component';
import { DispatchComponent } from './dispatch/dispatch.component';
import { CouponGenerationComponent } from './coupon-generation/coupon-generation.component';
import { ViewCouponsComponent } from './view-coupons/view-coupons.component';
import { ComposeMailComponent } from './compose-mail/compose-mail.component';
import { DeliveryStatusComponent } from './delivery-status/delivery-status.component';
import { OrderedProductsComponent } from './ordered-products/ordered-products.component';
import { PlacedProductsComponent } from './placed-products/placed-products.component';
import { DispatchedProductsComponent } from './dispatched-products/dispatched-products.component';
import { RefundComponent } from './refund/refund.component';

const routes: Routes = [
  
  {
    path:'showCust',
    component:ShowCustomersComponent
  },
  {
    path:'showMerch',
    component:ShowMerchantsComponent
  },
  {
    path:'manageMerch',
    component:ManageMerchantComponent
  },
  {
    path:'showInven',
    component:ShowInventoryComponent
  },
  {
    path:'showEmail',
    component:ShowEmailLogComponent
  },
  {
    path:'pendingReq',
    component:PendingRequestsComponent
  },
  {
    path:'totalRev',
    component:TotalRevenueComponent
  },
  {
    path: 'firstParty',
    component: AddDedicatedMerchantComponent
  },
  {
    path: 'thirdParty',
    component: AddThirdPartyMerchantComponent
  },
  {
    path: 'delete',
    component: RemoveMerchantComponent
  },
  {
    path: 'register',
    component: SignUpMerchantComponent
  },
  {
    path:'manageMerch',
    component:ManageMerchantComponent
  },
  {
    path:'inviteThirdParty',
    component:InviteThirdPartyMerchantComponent
  },
  {
    path:'inbox',
    component:InboxEmailComponent
  },
  {
    path:'sentbox',
    component:SentMailComponent
  },
  {
    path:'refund',
    component:RefundComponent
  },
  {
    path:'report',
    component:ReportComponent
  },
  {
    path:'dispatch',
    component:DispatchComponent
  },
  {
    path:'generate',
    component:CouponGenerationComponent
  },
  {
    path:'viewCoupons',
    component:ViewCouponsComponent
  },
  {
    path:'composeMail',
    component:ComposeMailComponent
  },
  {
    path:'allOrderedProducts',
    component:OrderedProductsComponent
  },
  {
    path:'placedProducts',
    component:PlacedProductsComponent
  },
  {
    path:'dispatchedProducts',
    component:DispatchedProductsComponent
  },
  
  {
    path:'deliveryStatus',
    component:DeliveryStatusComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
