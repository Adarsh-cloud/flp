import { Product } from './Product';

export class Rating{
    ratId:string;
    product:Product;
    currRating:number;
    ratingCount:number;
}